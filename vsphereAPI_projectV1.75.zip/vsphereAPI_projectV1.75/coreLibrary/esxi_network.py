#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from pyVim.connect import SmartConnect, SmartConnectNoSSL, Disconnect
from pyVmomi import vim
import json

# Capture ESXi host physical nics
def capture_host_pnics(host):
    host_pnics = []
    for pnic in host.config.network.pnic:
        pnic_info = dict()
        pnic_info.update(
            {'device': pnic.device, 'driver': pnic.driver, 'mac': pnic.mac})
        host_pnics.append(pnic_info)

    return host_pnics


# Capture ESXi host virtual nics
def capture_host_vnics(host):
    host_vnics = []
    for vnic in host.config.network.vnic:
        vnic_info = dict()
        vnic_info.update(
            {'device': vnic.device, 'portgroup': vnic.portgroup,
             'dhcp': vnic.spec.ip.dhcp, 'ipAddress': vnic.spec.ip.ipAddress,
             'subnetMask': vnic.spec.ip.subnetMask,
             'mac': vnic.spec.mac, 'mtu': vnic.spec.mtu})
        host_vnics.append(vnic_info)
    return host_vnics


# Capture ESXi host virtual switches
def capture_host_vswitches(host):
    host_vswitches = []
    for vswitch in host.config.network.vswitch:
        vswitch_info = dict()
        vswitch_pnics = []
        vswitch_portgroups = []
        for pnic in vswitch.pnic:
            pnic = pnic.replace('key-vim.host.PhysicalNic-', '')
            vswitch_pnics.append(pnic)
        for pg in vswitch.portgroup:
            pg = pg.replace('key-vim.host.PortGroup-', '')
            vswitch_portgroups.append(pg)
        vswitch_info.update(
            {'name': vswitch.name, 'pnics': vswitch_pnics,
             'portgroups': vswitch_portgroups, 'mtu': vswitch.mtu})
        host_vswitches.append(vswitch_info)

    return host_vswitches


def capture_host_portgroups(host):
    host_portgroups = []
    for portgroup in host.config.network.portgroup:
        portgroup_info = dict()
        portgroup_info.update(
            {'name': portgroup.spec.name, 'vlanId': portgroup.spec.vlanId,
             'vswitchName': portgroup.spec.vswitchName,
             'nicTeamingPolicy': portgroup.spec.policy.nicTeaming.policy,
             'allowPromiscuous': portgroup.spec.policy.security.allowPromiscuous,
             'macChanges': portgroup.spec.policy.security.macChanges,
             'forgedTransmits': portgroup.spec.policy.security.forgedTransmits})
        host_portgroups.append(portgroup_info)

    return host_portgroups


if __name__ == "__main__":
    main()
    
    
    
    
"""
[
  {
    "host": "10.0.101.61",
    "hostname": "localhost.localdomain",
    "vswitches": [
      {
        "pnics": ["vmnic0", "vmnic1"],
        "portgroups": ["Management Network", "VM Network"],
        "name": "vSwitch0",
        "mtu": 1500
      }
    ],
    "pnics": [
      {
        "device": "vmnic0",
        "mac": "00:23:7d:33:f0:6e",
        "driver": "bnx2"
      },
      {
        "device": "vmnic1",
        "mac": "00:23:7d:33:f0:5e",
        "driver": "bnx2"
      },
      {
        "device": "vmnic2",
        "mac": "e8:39:35:10:20:b9",
        "driver": "e1000e"
      },
      {
        "device": "vmnic3",
        "mac": "e8:39:35:10:20:b8",
        "driver": "e1000e"
      },
      {
        "device": "vmnic4",
        "mac": "e8:39:35:10:20:bb",
        "driver": "e1000e"
      },
      {
        "device": "vmnic5",
        "mac": "e8:39:35:10:20:ba",
        "driver": "e1000e"
      }
    ],
    "vnics": [
      {
        "mac": "00:23:7d:33:f0:6e",
        "dhcp": false,
        "device": "vmk0",
        "subnetMask": "255.255.255.0",
        "mtu": 1500,
        "ipAddress": "10.0.101.61",
        "portgroup": "Management Network"
      }
    ],
    "portgroups": [
      {
        "vswitchName": "vSwitch0",
        "forgedTransmits": null,
        "name": "Management Network",
        "allowPromiscuous": null,
        "nicTeamingPolicy": "loadbalance_srcid",
        "macChanges": null,
        "vlanId": 101
      },
      {
        "vswitchName": "vSwitch0",
        "forgedTransmits": null,
        "name": "VM Network",
        "allowPromiscuous": null,
        "nicTeamingPolicy": "loadbalance_srcid",
        "macChanges": null,
        "vlanId": 0
      }
    ]
  },
  
  
  
  
  
  
  {
    "host": "10.0.101.62",
    "hostname": "localhost.localdomain",
    "vswitches": [
      {
        "pnics": ["vmnic0", "vmnic1"],
        "portgroups": ["Management Network", "VM Network"],
        "name": "vSwitch0",
        "mtu": 1500
      }
    ],
    "pnics": [
      {
        "device": "vmnic0",
        "mac": "00:23:7d:33:47:f8",
        "driver": "bnx2"
      },
      {
        "device": "vmnic1",
        "mac": "00:23:7d:33:47:ec",
        "driver": "bnx2"
      },
      {
        "device": "vmnic2",
        "mac": "e8:39:35:10:21:dd",
        "driver": "e1000e"
      },
      {
        "device": "vmnic3",
        "mac": "e8:39:35:10:21:dc",
        "driver": "e1000e"
      },
      {
        "device": "vmnic4",
        "mac": "e8:39:35:10:21:df",
        "driver": "e1000e"
      },
      {
        "device": "vmnic5",
        "mac": "e8:39:35:10:21:de",
        "driver": "e1000e"
      }
    ],
    "vnics": [
      {
        "mac": "00:23:7d:33:47:f8",
        "dhcp": false,
        "device": "vmk0",
        "subnetMask": "255.255.255.0",
        "mtu": 1500,
        "ipAddress": "10.0.101.62",
        "portgroup": "Management Network"
      }
    ],
    "portgroups": [
      {
        "vswitchName": "vSwitch0",
        "forgedTransmits": null,
        "name": "Management Network",
        "allowPromiscuous": null,
        "nicTeamingPolicy": "loadbalance_srcid",
        "macChanges": null,
        "vlanId": 101
      },
      {
        "vswitchName": "vSwitch0",
        "forgedTransmits": null,
        "name": "VM Network",
        "allowPromiscuous": null,
        "nicTeamingPolicy": "loadbalance_srcid",
        "macChanges": null,
        "vlanId": 0
      }
    ]
  }
]
"""