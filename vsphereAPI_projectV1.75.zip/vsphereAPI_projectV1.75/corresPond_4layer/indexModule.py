#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from rootModule import vsphereSDK
from pyVmomi import vim


class sdkCorr():
    def __init__(self):
        self.content_var = vsphereSDK().loginContent_var()

    def content_virtHost(self):
        container = self.content_var.rootFolder
        view_type = [vim.VirtualMachine]
        rescursive = True
        containerView = self.content_var.viewManager.CreateContainerView(container,
                                                                         view_type,
                                                                         rescursive
                                                                         )
        childrenVar = containerView.view
        return childrenVar

    def content_esxiHost(self):
        container = self.content_var.rootFolder
        view_type = [vim.HostSystem]
        rescursive = True
        containerView = self.content_var.viewManager.CreateContainerView(container,
                                                                         view_type,
                                                                         rescursive
                                                                         )
        childrenVar = containerView.view
        return childrenVar

    def content_ClusterInfo(self):
        container = self.content_var.rootFolder
        view_type = [vim.ClusterComputeResource]
        rescursive = True
        containerView = self.content_var.viewManager.CreateContainerView(container,
                                                                         view_type,
                                                                         rescursive
                                                                         )
        children_var = containerView.view
        return children_var

    def content_Data_centerInfo(self):
        container = self.content_var.rootFolder
        view_type = [vim.Datacenter]
        rescursive = True
        containerView = self.content_var.viewManager.CreateContainerView(container,
                                                                         view_type,
                                                                         rescursive
                                                                         )
        children_var = containerView.view
        return children_var

# def main():
#     vsType = sdkCorrespond()
#     vspTools = vsphereSDK()
#     vspTools.jsonStyle_output(
#         printData=[
#             vsp_itm.name for vsp_itm in vsType.content_Data_centerInfo()
#         ]
#     )
#
#
# if __name__ == '__main__':
#     main()
