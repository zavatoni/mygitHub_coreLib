#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from rootModule import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr


class triggered_AlarmState():
    '''该对象，只获取;vim.Datacenter的监控巡检数据'''

    def __init__(self):
        self.dataCenter_api = sdkCorr()
        self.vsphereTool = vsphereSDK()
        self.warn_dict = dict()

    def dataCenter_warn(self):
        for self_itm in self.dataCenter_api.content_Data_centerInfo():
            iterDict = dict()
            iterNum = 0
            for self_iter in self_itm.triggeredAlarmState:
                iterDict.update(
                    {'entityName': self_iter.entity.name,
                     'entity_overallStatus': self_iter.entity.overallStatus,
                     'entity_configStatus': self_iter.entity.configStatus,
                     'triggered_overallStatus': self_iter.overallStatus,
                     'warning time': str(self_iter.time),
                     'alarmName': self_iter.alarm.info.name,
                     'alarm systemName': self_iter.alarm.info.systemName,
                     'alarm Description': self_iter.alarm.info.description,
                     }
                )
                warnKey = "{}:WAR{}".format(self_itm.name, iterNum)
                self.warn_dict.update(
                    {
                        warnKey: iterDict
                    }
                )
                iterNum += 1
        return self.warn_dict

    def vimCluster_warn(self):
        for self_itm in self.dataCenter_api.content_ClusterInfo():
            alarm_list = list(self_itm.triggeredAlarmState)
            if len(alarm_list) > 0:
                self_data = dict()
                for state_itm in range(len(alarm_list)):
                    self_data.update(
                        {
                            "key": alarm_list[state_itm].key,
                            'entityName': alarm_list[state_itm].entity.name,
                            'infoName': alarm_list[state_itm].alarm.info.name,
                            'entity_overallStatus': alarm_list[state_itm].entity.overallStatus,
                            'entity_configStatus': alarm_list[state_itm].entity.configStatus,
                            'systemName': alarm_list[state_itm].alarm.info.systemName,
                            'infoDescription': alarm_list[state_itm].alarm.info.description,
                            'overallStatus': alarm_list[state_itm].overallStatus
                        }
                    )
                    store_dict = self.vsphereTool.listTodict(
                        dictStr='store',
                        listStyle=[store_itm.name for store_itm in alarm_list[state_itm].entity.datastore]
                    )
                    for key, val in store_dict.items():
                        self_data[key] = val
                    self.warn_dict.update(
                        {
                            '{}:War-{}'.format(self_itm.name, state_itm): self_data
                        }
                    )
        return self.warn_dict

    def vimHost_warn(self):
        for self_itm in self.dataCenter_api.content_esxiHost():
            alarm_list = list(self_itm.triggeredAlarmState)
            if len(alarm_list) > 0:
                selfName = str(self_itm.name).split('.')[0]
                self_data = dict()
                for state_itm in range(len(alarm_list)):
                    set_alarmState=alarm_list[state_itm]
                    self_data.update(
                        {
                            "key": set_alarmState.key,
                            'entityName': set_alarmState.entity.name,
                            'infoName': set_alarmState.alarm.info.name,
                            'systemName': set_alarmState.alarm.info.systemName,
                            'infoDescription': set_alarmState.alarm.info.description,
                            'overallStatus': set_alarmState.overallStatus,
                            'entity_overallStatus':set_alarmState.entity.overallStatus,
                            'entity_configStatus':set_alarmState.entity.configStatus
                        }
                    )
                    setWarn = self.vsphereTool.listTodict(
                        dictStr='storeName',
                        listStyle=[store_itm.name for store_itm in alarm_list[state_itm].entity.datastore]
                    )
                    for key,val in setWarn.items():
                        self_data[key]=val
                    self.warn_dict.update(
                        {
                            '{}:War-{}'.format(selfName, state_itm): self_data
                        }
                    )
        return self.warn_dict

    def warningSeq(self):
        entityList = []
        for self_itm in self.dataCenter_api.content_Data_centerInfo():
            for self_iter in self_itm.triggeredAlarmState:
                entityList.append(('entityKey', self_iter.entity), )
        return entityList


from pandas import DataFrame
from pandas import ExcelWriter
from time import strftime

vsTool = vsphereSDK()


def main():
    vsphereSDK().jsonPrint(outData=triggered_AlarmState().vimHost_warn())


if __name__ == '__main__':
    main()
