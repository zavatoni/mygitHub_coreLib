#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from rootModule import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr


class esxiSum():
    def __init__(self):
        self.esxi_seq = list(sdkCorr().content_esxiHost())
        self.summaryDict = dict()

    def hardwareInfo(self):
        esxi_seq = list(sdkCorr().content_esxiHost())
        for host_itm in esxi_seq:
            esxiChar = str(host_itm.name).split('.')[0]
            self.summaryDict.update(
                {esxiChar: {'hostName': host_itm.summary.host.name,
                            'hardwareVendor': host_itm.summary.hardware.vendor,
                            'hardwareModel': host_itm.summary.hardware.model,
                            'hardwareUUID': host_itm.summary.hardware.uuid,
                            'hardwareMemory_size': host_itm.summary.hardware.memorySize,
                            'hardwarecpuModel': host_itm.summary.hardware.cpuModel,
                            'hardwarecpuMhz': host_itm.summary.hardware.cpuMhz,
                            'hardwarenumCpuPkgs': host_itm.summary.hardware.numCpuPkgs,
                            'hardwarenumCpuCores': host_itm.summary.hardware.numCpuCores,
                            'hardwarenumCpuThreads': host_itm.summary.hardware.numCpuThreads,
                            'hardwarenumNics': host_itm.summary.hardware.numNics,
                            'hardwarenumHBAs': host_itm.summary.hardware.numHBAs
                            }
                 }
            )
        return self.summaryDict

    def runtimeInfo(self):
        for host_itm in self.esxi_seq:
            esxiChar = str(host_itm.name).split('.')[0]
            self.summaryDict.update(
                {esxiChar: {'runtime bootTime': str(host_itm.summary.runtime.bootTime),
                            'runtime connectionState': host_itm.summary.runtime.connectionState,
                            'runtime powerState': host_itm.summary.runtime.powerState
                            }
                 }
            )
            health_list = list(
                host_itm.summary.runtime.healthSystemRuntime.systemHealthInfo.numericSensorInfo
            )
            infoDict = dict()
            for numer_itm in range(len(health_list)):
                infoDict.update(
                    {'healthState label': health_list[numer_itm].healthState.label,
                     'healthState key': health_list[numer_itm].healthState.key,
                     'currentReading': health_list[numer_itm].currentReading,
                     'unitModifier': health_list[numer_itm].unitModifier,
                     'baseUnits': health_list[numer_itm].baseUnits,
                     'rateUnits': health_list[numer_itm].rateUnits,
                     'sensorType': health_list[numer_itm].sensorType,
                     'id': health_list[numer_itm].id,
                     'timeStamp': str(health_list[numer_itm].timeStamp)
                     }
                )
            self.summaryDict.update({"{}-health".format(esxiChar): infoDict})
        return self.summaryDict

    def runtime_healthSystemRuntime_hardwareStatusInfo(self):
        esxi_seq = list(sdkCorr().content_esxiHost())
        for host_itm in esxi_seq:
            runtime_list = list(
                host_itm.summary.runtime.healthSystemRuntime.hardwareStatusInfo.cpuStatusInfo
            )
            # health_dict = dict()
            num = 0
            for esxi_itm in range(len(runtime_list)):
                setKey = "{}:{}".format(str(host_itm.name).split('.')[0], num)
                setEsxi_itm = runtime_list[esxi_itm]
                self.summaryDict.update(
                    {
                        setKey: {"name".format(num): setEsxi_itm.name,
                                 "status label".format(num): setEsxi_itm.status.label,
                                 "status summary".format(num): setEsxi_itm.status.summary,
                                 "status key".format(num): setEsxi_itm.status.key
                                 }
                    }
                )
                num += 1
        return self.summaryDict

    def runtime_vsanRuntime_membershipListInfo(self):
        esxi_seq = list(sdkCorr().content_esxiHost())
        for host_itm in self.esxi_seq:
            membershipList = list(
                host_itm.summary.runtime.vsanRuntimeInfo.membershipList
            )
            if len(membershipList) > 0:
                num = 0
                for ship_itm in range(len(membershipList)):
                    self.summaryDict.update(
                        {"cluster{}".format(num): {'nodeUUID': membershipList[ship_itm].nodeUuid,
                                                   'hostName': membershipList[ship_itm].hostname
                                                   }
                         }
                    )
                    num += 1
        return self.summaryDict

    def runtime_networkRuntimeInfo_netStackInstanceRuntimeInfo(self):
        for host_itm in self.esxi_seq:
            esxiName = str(host_itm.name).split('.')[0]
            info_list = list(
                host_itm.summary.runtime.networkRuntimeInfo.netStackInstanceRuntimeInfo
            )
            esxi_dict = dict()
            for network_itm in range(len(info_list)):
                setRuntime=info_list[network_itm]
                esxi_dict.update(
                    {'netStackInstanceKey': setRuntime.netStackInstanceKey,
                     'state': setRuntime.state,
                     'maxNumberOfConnections': setRuntime.maxNumberOfConnections
                     }
                )
                set_vstool = vsTool.listTodict(
                    dictStr='Keys',
                    listStyle=info_list[network_itm].vmknicKeys
                )
                for key,val in set_vstool.items():
                    esxi_dict["vmknic{}".format(key)]=val
                esxi_dict['hostMaxVirtualDiskCapacity']=host_itm.summary.runtime.hostMaxVirtualDiskCapacity
                esxi_dict['cryptoState']=host_itm.summary.runtime.cryptoState
            self.summaryDict.update({"{}:net".format(esxiName): esxi_dict})

        return self.summaryDict

    def configInfo(self):
        esxi_seq = list(sdkCorr().content_esxiHost())
        for host_itm in esxi_seq:
            esxiName = str(host_itm.name).split('.')[0]
            self.summaryDict.update(
                {'{}:config'.format(esxiName): {
                    'maxEVCModeKey': host_itm.summary.maxEVCModeKey,
                    'managementServerIp': host_itm.summary.managementServerIp,
                    'overallStatus': host_itm.summary.overallStatus,
                    'product licenseProductVersion': host_itm.summary.config.product.licenseProductVersion,
                    'product apiVersion': host_itm.summary.config.product.apiVersion,
                    'product apiType': host_itm.summary.config.product.apiType,
                    'product localeBuild': host_itm.summary.config.product.localeBuild,
                    'product osType': host_itm.summary.config.product.osType,
                    'product localeVersion': host_itm.summary.config.product.localeVersion,
                    'product build': host_itm.summary.config.product.build,
                    'product version': host_itm.summary.config.product.version,
                    'product vendor': host_itm.summary.config.product.vendor,
                    'product fullName': host_itm.summary.config.product.fullName,
                    'productName': host_itm.summary.config.product.name,
                    'sslThumbprint': host_itm.summary.config.sslThumbprint,
                    'port': host_itm.summary.config.port,
                    'name': host_itm.summary.config.name
                }
                }
            )
            if 'NoneType' not in str(type(host_itm.summary.quickStats)):
                self.summaryDict.update(
                    {'{}:quick'.format(esxiName): {
                        'overallCpuUsage': host_itm.summary.quickStats.overallCpuUsage,
                        'overallMemoryUsage': host_itm.summary.quickStats.overallMemoryUsage,
                        'distributedCpuFairness': host_itm.summary.quickStats.distributedCpuFairness,
                        'availablePMemCapacity': host_itm.summary.quickStats.availablePMemCapacity,
                        'uptime': host_itm.summary.quickStats.uptime
                    }
                    }
                )
            elif 'NoneType' not in str(type(host_itm.summary.currentEVCModeKey)):
                self.summaryDict.update(
                    {esxiName: {
                        'currentEVCModeKey': host_itm.summary.currentEVCModeKey
                    }
                    }
                )
        return self.summaryDict


vsTool = vsphereSDK()


def main():
    esxiSum().configInfo()
    # vsTool.jsonPrint(outData=esxiSum().configInfo())


if __name__ == '__main__':
    main()
