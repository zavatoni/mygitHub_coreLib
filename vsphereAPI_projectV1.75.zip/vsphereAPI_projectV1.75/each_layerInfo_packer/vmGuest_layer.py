#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from rootModule import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr


class vmGuestsummary():
    def __init__(self):
        self.vsTool = vsphereSDK()
        self.vs_dict = dict()

    def runtimeBase(self):
        for virt_itm in sdkCorr().content_virtHost():
            self.vs_dict.update({"{}:runtime".format(virt_itm.name): {
                'suspendInterval': virt_itm.summary.runtime.suspendInterval,
                'recordReplayState': virt_itm.summary.runtime.recordReplayState,
                'numMksConnections': virt_itm.summary.runtime.numMksConnections,
                'faultToleranceState': virt_itm.summary.runtime.faultToleranceState,
                'powerState': virt_itm.summary.runtime.powerState,
                'connectionState': virt_itm.summary.runtime.connectionState,
                'vmName': virt_itm.summary.runtime.host.name
            }
            }
            )
            if 'NoneType' not in str(type(virt_itm.summary.runtime.maxCpuUsage)) and 'NoneType' not in str(
                    type(virt_itm.summary.runtime.maxMemoryUsage)):
                self.vs_dict.update({"{}:Usage".format(virt_itm.name): {
                    'maxCpuUsage': virt_itm.summary.runtime.maxCpuUsage,
                    'maxMemoryUsage': virt_itm.summary.runtime.maxMemoryUsage
                }
                }
                )
        return self.vs_dict

    def guestBase(self):
        for virt_itm in sdkCorr().content_virtHost():
            self.vs_dict.update({virt_itm.name: {'guest toolsStatus': virt_itm.summary.guest.toolsRunningStatus,
                                                 'guest toolsVersionStatus2': virt_itm.summary.guest.toolsVersionStatus2,
                                                 'guest toolsRunningStatus': virt_itm.summary.guest.toolsRunningStatus
                                                 }
                                 }
                                )
        return self.vs_dict

    def configBase(self):
        for virt_itm in sdkCorr().content_virtHost():
            self.vs_dict.update({"{}:config".format(virt_itm.name): {
                'configName': virt_itm.summary.config.name,
                'config vmPathName': virt_itm.summary.config.vmPathName,
                'config memorySizeMB': virt_itm.summary.config.memorySizeMB,
                'config cpuReservation': virt_itm.summary.config.cpuReservation,
                'config memoryReservation': virt_itm.summary.config.memoryReservation,
                'config numCpu': virt_itm.summary.config.numCpu,
                'config numEthernetCards': virt_itm.summary.config.numEthernetCards,
                'config numVirtualDisks': virt_itm.summary.config.numVirtualDisks,
                'config Uuid': virt_itm.summary.config.uuid,
                'config instanceUuid': virt_itm.summary.config.instanceUuid,
                'config guestId': virt_itm.summary.config.guestId,
                'config guestFullName': virt_itm.summary.config.guestFullName,
                'config annotation': virt_itm.summary.config.annotation,
                'config numVmiopBackings': virt_itm.summary.config.numVmiopBackings
            }
            }
            )
        return self.vs_dict

    def storageBase(self):
        for virt_itm in sdkCorr().content_virtHost():
            self.vs_dict.update({
                "{}:storage".format(virt_itm.name): {
                    'storage committed': virt_itm.summary.storage.committed,
                    'storage unshared': virt_itm.summary.storage.unshared,
                    'storage uncommitted': virt_itm.summary.storage.uncommitted,
                    'storage timestamp': str(virt_itm.summary.storage.timestamp)
                }
            }
            )
        return self.vs_dict

    def quickStatsBase(self):
        for virt_itm in sdkCorr().content_virtHost():
            self.vs_dict.update({
                "{}:quick".format(virt_itm.name): {
                    'quickStats overallCpuUsage': virt_itm.summary.quickStats.overallCpuUsage,
                    'quickStats overallCpuDemand': virt_itm.summary.quickStats.overallCpuDemand,
                    'quickStats guestMemoryUsage': virt_itm.summary.quickStats.guestMemoryUsage,
                    'quickStats hostMemoryUsage': virt_itm.summary.quickStats.hostMemoryUsage,
                    'quickStats guestHeartbeatStatus': virt_itm.summary.quickStats.guestHeartbeatStatus,
                    'quickStats distributedCpuEntitlement': virt_itm.summary.quickStats.distributedCpuEntitlement,
                    'quickStats distributedMemoryEntitlement': virt_itm.summary.quickStats.distributedMemoryEntitlement,
                    'quickStats staticCpuEntitlement': virt_itm.summary.quickStats.staticCpuEntitlement,
                    'quickStats staticMemoryEntitlement': virt_itm.summary.quickStats.staticMemoryEntitlement,
                    'quickStats privateMemory': virt_itm.summary.quickStats.privateMemory,
                    'quickStats sharedMemory': virt_itm.summary.quickStats.sharedMemory,
                    'quickStats swappedMemory': virt_itm.summary.quickStats.swappedMemory,
                    'quickStats balloonedMemory': virt_itm.summary.quickStats.balloonedMemory,
                    'quickStats consumedOverheadMemory': virt_itm.summary.quickStats.consumedOverheadMemory,
                    'quickStats ftLogBandwidth': virt_itm.summary.quickStats.ftLogBandwidth,
                    'quickStats ftSecondaryLatency': virt_itm.summary.quickStats.ftSecondaryLatency,
                    'quickStats ftLatencyStatus': virt_itm.summary.quickStats.ftLatencyStatus,
                    'quickStats compressedMemory': virt_itm.summary.quickStats.compressedMemory,
                    'quickStats uptimeSeconds': virt_itm.summary.quickStats.uptimeSeconds,
                    'quickStats ssdSwappedMemory': virt_itm.summary.quickStats.ssdSwappedMemory,
                    'overallStatus': virt_itm.summary.overallStatus
                }
            })
        return self.vs_dict

    def networkBase(self):
        for virt_itm in sdkCorr().content_virtHost():
            netWork = dict()
            netWork_iter = 0
            for vm_net in virt_itm.network:
                netWork.update(
                    {
                        'name:{}'.format(netWork_iter): vm_net.summary.name,
                        'accessible:{}'.format(netWork_iter): vm_net.summary.accessible,
                        'overallStatus:{}'.format(netWork_iter): vm_net.overallStatus
                    }
                )
            self.vs_dict.update(
                {
                    virt_itm.name: netWork

                }
            )
        return self.vs_dict


from pandas import DataFrame
from pandas import ExcelWriter
from time import strftime

vsTools = vsphereSDK()


def main():
    readConfig = vsTools.vsphereConfig(configStr='Conf\Account.yml')
    for readKey in readConfig.keys():
        if len(readConfig.get(readKey)) > 0:
            vmGuest_runtime = DataFrame.from_dict(vmGuestsummary().runtimeBase()).T
            vmGuest_guest = DataFrame.from_dict(vmGuestsummary().guestBase()).T
            vmGuest_config = DataFrame.from_dict(vmGuestsummary().configBase()).T
            vmGuest_storage = DataFrame.from_dict(vmGuestsummary().storageBase()).T
            vmGuest_quickStats = DataFrame.from_dict(vmGuestsummary().quickStatsBase()).T
            vmGuest_network = DataFrame.from_dict(vmGuestsummary().networkBase()).T
            with ExcelWriter(
                    'dataStore/vmGuest{}Base{}info.xlsx'.format(strftime("%Y%m%d-%H"),
                                                                readConfig.get(readKey)['name'])) as gf:
                vmGuest_config.to_excel(gf, sheet_name='configure BaseInfo')
                vmGuest_runtime.to_excel(gf, sheet_name='runtime BaseInfo')
                vmGuest_guest.to_excel(gf, sheet_name='guest BaseInfo')
                vmGuest_storage.to_excel(gf, sheet_name='storage BaseInfo')
                vmGuest_quickStats.to_excel(gf, sheet_name='quickStats BaseInfo')
                vmGuest_network.to_excel(gf, sheet_name='netWork Base Info')
            vsTools.sheetTable_Style(
                ex_str='dataStore/vmGuest{}Base{}info.xlsx'.format(strftime("%Y%m%d-%H"),
                                                                   readConfig.get(readKey)['name'])
            )


if __name__ == '__main__':
    main()
