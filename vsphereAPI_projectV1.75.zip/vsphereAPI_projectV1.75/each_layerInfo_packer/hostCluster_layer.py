#!/usr/bin/python3
# -*- coding:UTF-8 -*-
from rootModule import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr


class vimclusterStatus():
    def __init__(self):
        self.sumDict = dict()
        self.clusterInfo = list(sdkCorr().content_ClusterInfo())

    def summary(self):
        for host_itm in self.clusterInfo:
            self.sumDict.update(
                {host_itm.name: {'totalCpu': host_itm.summary.totalCpu,
                                 'totalMemory': host_itm.summary.totalMemory,
                                 'numCpuCores': host_itm.summary.numCpuCores,
                                 'numCpuThreads': host_itm.summary.numCpuThreads,
                                 'effectiveCpu': host_itm.summary.effectiveCpu,
                                 'effectiveMemory': host_itm.summary.effectiveMemory,
                                 'numHosts': host_itm.summary.numHosts,
                                 'numEffectiveHosts': host_itm.summary.numEffectiveHosts,
                                 'overallStatus': host_itm.summary.overallStatus,
                                 'currentFailoverLevel': host_itm.summary.currentFailoverLevel,
                                 'totalCpuCapacityMhz': host_itm.summary.usageSummary.totalCpuCapacityMhz,
                                 'totalMemCapacityMB': host_itm.summary.usageSummary.totalMemCapacityMB,
                                 'cpuReservationMhz': host_itm.summary.usageSummary.cpuReservationMhz,
                                 'memReservationMB': host_itm.summary.usageSummary.memReservationMB,
                                 'poweredOffCpuReservationMhz': host_itm.summary.usageSummary.poweredOffCpuReservationMhz,
                                 'poweredOffMemReservationMB': host_itm.summary.usageSummary.poweredOffMemReservationMB,
                                 'cpuDemandMhz': host_itm.summary.usageSummary.cpuDemandMhz,
                                 'memDemandMB': host_itm.summary.usageSummary.memDemandMB,
                                 'poweredOffVmCount': host_itm.summary.usageSummary.poweredOffVmCount,
                                 'totalVmCount': host_itm.summary.usageSummary.totalVmCount,
                                 'currentEVCModeKey': host_itm.summary.currentEVCModeKey
                                 }
                 }
            )
        return self.sumDict

    def networkInfo(self):
        for netCase in self.clusterInfo:
            case = list(netCase.network)
            for itm in range(len(case)):
                setCase = case[itm]
                keyStr = '{}:net-{}'.format(netCase.name, itm)
                self.sumDict.update(
                    {
                        keyStr: {
                            'name': setCase.name,
                            'configStatus': setCase.configStatus,
                            'overallStatus': setCase.overallStatus
                        }
                    }
                )
        return self.sumDict

    def systemInfo(self):
        for tagCase in self.clusterInfo:
            self.sumDict.update(
                {
                    "{}:sys".format(tagCase.name): {
                        'overallStatus': tagCase.overallStatus,
                        'configStatus': tagCase.configStatus
                    }
                }
            )
        return self.sumDict

    def dataStore(self):
        for tag in self.clusterInfo:
            set_store = list(tag.datastore)
            for itm in range(len(set_store)):
                setItm = set_store[itm]
                setKey = "{}:Store-{}".format(tag.name, itm)
                self.sumDict.update(
                    {
                        setKey: {
                            'name': setItm.name,
                            'overallStatus': setItm.overallStatus,
                            'configStatus': setItm.configStatus
                        }
                    }
                )
        return self.sumDict

    def parent(self):
        for case in self.clusterInfo:
            keyStr = "{}:parent".format(case.name)
            self.sumDict.update(
                {
                    keyStr: {
                        'overallStatus': case.parent.overallStatus,
                        'configStatus': case.parent.configStatus
                    }
                }
            )
        return self.sumDict

    def resourcePool(self):
        for case in self.clusterInfo:
            keyStr = "{}:pool".format(case.name)
            self.sumDict.update(
                {
                    keyStr: {
                        'overallStatus': case.resourcePool.overallStatus,
                        'configStatus': case.resourcePool.configStatus
                    }
                }
            )
        return self.sumDict

    def hciConfig(self):
        for case in self.clusterInfo:
            if 'NoneType' not in str(type(case.hciConfig)):
                self.sumDict.update(
                    {'{}:hci'.format(case.name): {'workflowState': case.hciConfig.workflowState}}
                )
        return self.sumDict

    def Example(self):
        for tagCase in self.clusterInfo:
            # print(dir(tagCase))
            '''
            'configStatus','name', 'network', 'overallStatus', '', '', '', ' ', ' ', 'setCustomValue', 'summary', 'tag', 'triggeredAlarmState', 'value'
            '''

            print(
                # tagCase.declaredAlarmState
                # tagCase.environmentBrowser,
                # tagCase.host,
                # tagCase.parent

            )
            print(tagCase.name)
            print(tagCase.resourcePool.overallStatus)
            print(tagCase.resourcePool.configStatus)

            print(tagCase.name)
            print()


vsTool = vsphereSDK()


def main():
    # hostCLuststatus().Example()
    setInfo = hostCLuststatus().declaredAlarmState()
    vsTool.jsonPrint(outData=setInfo)


if __name__ == '__main__':
    main()
